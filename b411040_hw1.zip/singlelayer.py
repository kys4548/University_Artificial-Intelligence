import numpy as np


class singleLayer :
    def __init__(self, W, Bias): # 제공. 호출 시 작동하는 생성자
        self.W = W
        self.B = Bias

    def SetParams(self, W_params, Bias_params): # 제공. W와 Bias를 바꾸고 싶을 때 쓰는 함수
        self.W = W_params
        self.B = Bias_params

    def ScoreFunction(self, X): # \Score값 계산 -> 직접작성
        #3.2
        if X.ndim == 2:
            ScoreMatrix = np.zeros([X.shape[0], 10])
        elif X.ndim ==1 :
            ScoreMatrix = np.zeros([10,])

        ScoreMatrix=np.dot(X,self.W)+self.B
        return ScoreMatrix
    '''
    X가 2차원 넘파이 배열일때
    ScoreMatrix의 행은 X의 행의 갯수(이미지의 갯수) 열은 10개의 레이블을 나타내야하므로 
    [X.shape[0],10]의 넘파이 배열으로 표현하고 각각의 값들을 0으로 초기화하였다.
    X[60000,784] doc W[784,10] => ScoreMatrix[60000,10]
    
    X가 1차원 넘파이 배열일때
    ScoreMatrix의 행은 X의 행의 갯수(이미지가 하나므로 1) 열은 10개의 레이블을 나타내야 하므로
    [10,]의 넘파이 배열으로 표현하고 각각의 값들을 0으로 초기화하였다.
    X[1,784] doc W[784,10] => ScoreMatrix[10,]
    
    ScoreMatrix는 입력받은 이미지와(X)과 가중치(W)를 doc연산하고 거기에 Bias(B)를 더해 이미지에 대한 레이블들의 스코어를 나타낸 배열이다.
    ScoreFunction은 ScoreMatrix를 반환한다.
    '''

    def Softmax(self, ScoreMatrix): # 제공.
        if ScoreMatrix.ndim == 2:
            temp = ScoreMatrix.T
            temp = temp - np.max(temp, axis=0)
            y_predict = np.exp(temp) / np.sum(np.exp(temp), axis=0)
            return y_predict.T
        temp = ScoreMatrix - np.max(ScoreMatrix, axis=0)
        expX = np.exp(temp)
        y_predict = expX / np.sum(expX)
        return y_predict

    '''
    스코어값들이 들어가 있는 배열을 넣으면 각 값들이 정규화된 스코어(확률)로 변환되서 리턴된다.
    이미지마다 각 레이블들의 정규화된 스코어(확률)의 합은 1이다.
    
    ScoreMartix가 2차원 일때
    [N,10]
    
    ScoreMartix가 1차원 일때는 axis=0이 행을 의미해서 
    np.max(ScoreMatrix, axis=0)이 그 배열에서의최대값을 바로 찾아주는구나  
    [10, ]
    '''

    def LossFunction(self, y_predict, Y): #  Loss Function을 구하십시오 -> 직접 작성
        #3.3
        if y_predict.ndim == 2 and Y.ndim == 2 :
            loss = np.sum(-np.log(y_predict)*Y,axis=1)
            loss= np.sum(loss)/loss.shape[0]
        elif y_predict.ndim == 1 and Y.ndim == 1:
            loss = np.sum(-np.log(y_predict)*Y)
        return loss

    '''
    y_predict.ndim == 2 and Y.ndim == 2 일때는 이미지셋 전체의 loss 넘파이 배열을 구할수 있다.
    -np.log(y_predict)*Y 연산을 하면 각 행마다 하나의 값만 0이 아닌 값을 가진다. 
    따라서 axis=1을 이용해 각 행마다 총합을 구해서 넘파이 배열을 만들고 loss에 넘겨주면 이미지셋 전체의 loss를 구할수 있다.
    이미지셋 전체의loss를 갯수로 나눠 loss의 평균을 구할수 있다.
    
     y_predict.ndim == 1 and Y.ndim == 1 일때는 이미지 하나의 loss 값을 구할수 있다.
     -np.log(y_predict)*Y 연산을 하면 전체값 중 하나의 값만 0이 아닌 값을 가진다.
     따라서 전체 값을 더해 loss에 넘겨주면 이미지의 loss를 구할수 있다. 

     LossFunction함수는 loss를 리턴한다.
    '''
    def Forward(self, X, Y): # ScoreFunction과 Softmax, LossFunction를 적절히 활용해 y_predict 와 loss를 리턴시키는 함수. -> 직접 작성
        #3.4
        temp = self.ScoreFunction(X)
        y_predict = self.Softmax(temp)
        loss = self.LossFunction(y_predict,Y)

        return y_predict, loss

    '''
    위에 함수 옆에 주석처리된 부분에서 모든것을 설명하고 있다. 
    위 주석처리된 순서대로 함수를 실행시키면 순서대로 스코어를 구하고 정규화를 하고 loss가 얼마인지 구할수 있다.
    '''


    def delta_Loss_Scorefunction(self, y_predict, Y): # 제공.dL/dScoreFunction
        delta_Score = y_predict - Y
        return delta_Score

    def delta_Score_weight(self, delta_Score, X): # 제공. dScoreFunction / dw .
        delta_W = np.dot(X.T, delta_Score) / X[0].shape
        return delta_W

    def delta_Score_bias(self, delta_Score, X): # 제공. dScoreFunction / db .
        delta_B = np.sum(delta_Score) / X[0].shape
        return delta_B

    # delta 함수를 적절히 써서 delta_w, delta_b 를 return 하십시오.
    def BackPropagation(self, X, y_predict, Y):
        #3.5
        delta_Score = self.delta_Loss_Scorefunction(y_predict,Y)
        delta_W = self.delta_Score_weight(delta_Score, X)
        delta_B = self.delta_Score_bias(delta_Score, X)
        return delta_W, delta_B

    '''
    위에 주어진 3개의 편미분 함수들로 체인룰을 적용한다.
     delta_Loss_Scorefunction(y_predict,Y) : dL/dScoreFunction값을 구한다.
     (dL/dScoreFunction) * (dScoreFunction/dw) = dL/dw  : W값의 변화에 따른 Loss 변화량,  self.delta_Score_weight(delta_Score, X)이용
     (dL/dScoreFunction) * (dScoreFunction/db) = dL/db  : Bias값의 변화에 따른 Loss 변화량, delta_B = self.delta_Score_bias(delta_Score, X)
    '''


    # 정확도를 체크하는 Accuracy 제공
    def Accuracy(self, X, Y):
        y_score = self.ScoreFunction(X)
        y_score_argmax = np.argmax(y_score, axis=1)
        if Y.ndim!=1 : Y = np.argmax(Y, axis=1)
        accuracy =100 * np.sum(y_score_argmax == Y) / X.shape[0]
        return accuracy

    # Forward와 BackPropagationAndTraining, Accuracy를 사용하여서 Training을 epoch만큼 시키고, 10번째 트레이닝마다
    # Training Set의 Accuracy 값과 Test Set의 Accuracy를 print 하십시오

    def Optimization(self, X_train, Y_train, X_test, Y_test, learning_rate = 0.01, epoch=100):
        for i in range(epoch):

        #전체적인 행위를 100번 반복한다.
        #학습률은 0.01
            #3.6
            # 함수 작성
            y_predict, loss = self.Forward(X_train,Y_train)
            delta_W, delta_B = self.BackPropagation(X_train,y_predict,Y_train)

            '''
            앞에서 정의한 Forward함수로 각 이미지들의 라벨 예측 값 y_predict [60000,10] 넘파이 행렬과 각 이미지들의 loss값의 합을 구한다.
            앞에서 정의한 BackPropagation함수로  W값의 변화에 따른 Loss 변화량, Bias값의 변화에 따른 Loss 변화량을 구한다.
            '''
            self.SetParams(self.W-delta_W*learning_rate,self.B-delta_B*learning_rate)

            #최적의 W와 Bias값을 찾기위해 W값과 Bias값을 미세하게 변화시키는 작업을 반복한다.


            if i % 10 == 0: # 10번 반복할때마다 마다 train 셋과 test셋의 정확도 확인하기 위해서 실행한다.

                #3.6 Accuracy 함수 사용
                print(i, "번째 트레이닝") # 트레이닝 횟수 출력
                print('현재 Loss(Cost)의 값 : ', loss)  #Loss값 출력
                print("Train Set의 Accuracy의 값 : ",self.Accuracy(X_train,Y_train)) #train set 정확도 출력
                print("Test Set의 Accuracy의 값 :", self.Accuracy(X_test,Y_test)) #test set 정확도 출력

    def Numerical_Gradient(self, X, Y, h=0.00001):
        y_predict1, loss1 = self.Forward(X,Y) #기존 loss 값을 구한다.
        dW = np.zeros([784,10]) #dW값을 저장할 W와 크기가 같은 넘파이 행렬을 만든다.

        for i in range(self.W.shape[0]): #W의 행의 수만큼 반복한다. 784회
            for j in range(self.W.shape[1]): #W의 열의 수만큼 반복한다  10회 =>총 784*10회 반복
                temp_W = self.W #현재 가중치 행렬을 temp_W라는 값에 받는다.
                temp_W[i][j]+=h #temp_W행렬의 [i][j]에 해당하는 값만 0.00001 증가 시킨다.
                self.SetParams(temp_W, self.B) # temp_W 값을 클래스의 W파라미터에 저장시킨다.
                y_predict2, loss2 = self.Forward(X, Y) # 변경된 W파라미터에 따른 Loss값을 구한다.
                dW[i][j] = (loss2-loss1)/h #변화된 W값에 따른 Loss값의 변화량을 구한다.
                temp_W[i][j] -= h #temp_W행렬의 [i][j]에 해당하는 값만 0.00001 감소 시킨다.
                self.SetParams(temp_W, self.B) #그값을 클래스의 W파라미터에 저장시킨다.(원상복귀 시킨다.)
        return dW


def OneHotIncodedLabel(X):
    labels = np.zeros([4, ])
    if X == 0:
        labels[0] = 1
    elif X == 1:
        labels[1] = 1
    elif X == 2:
        labels[2] = 1
    elif X == 3:
        labels[3] = 1
    return labels

'''
4개의 0을 가지는 넘파이 행렬 labels를 정의하고 함수로 들어오는 입력값 X(0~3)에 따라 
labels 의 4개의 값중 1개만 1로 바꾼다.
'''


