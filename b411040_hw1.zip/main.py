import numpy as np
from mnist import load_mnist
import singlelayer as sn #SingleayerNetwork
from PIL import Image
np.random.seed(1)

def img_show(img): # (784) 혹은 (28, 28)의 mnist 배열을 이미지로 보여주는 작업
   if img.ndim==1:
      img = img.reshape(28, 28)
      img *= 255.0
      pil_img = Image.fromarray(np.uint8(img))
      pil_img.show()
      img /= 255.0
      '''
      이미지로 보여지기 위해 각 넘파이 배열값들에 255을 곱하기만 하고 원래대로 되돌려놓지를 않아서 
      만약 img_show함수를 여러번 출력한다면 픽셀값(0~255)이 아닌 더 큰값이 나오기도 하고,
      TestNN함수내에서 x_train[i]값이 변경되어 실제 img_show함수 뒷부분에서는 x_train[i]넘파일 배열값들이 
      0과 1사이가 아닌 0~255사이가 되어버린다. 
      그러면 처음 데이터셋을 받아올때 normalize옵션을 한 이유가 사라지기 때문에 
      img /= 255코드 한줄을 추가하였습니다.
      '''



def get_data(): # mnist 데이터 받아오기(one_hot_label로)
   (x_train, y_train), (x_test, y_test) = \
   load_mnist(normalize=True, flatten=True, one_hot_label=True)

   '''
   1) normalize : 입력 이미지의 픽셀을 0.0 ~ 1.0 사이의 값으로 정규화 할지(True) 
   아니면 기존 그대로 0 ~ 255 사이의 값을 사용할 지(False)
   2) flatten : 입력 이미지를 1차원 배열로 변환할지(True), 1x28x28 로 유지할 지(False)
   3) one_hot_label : 원 핫 인코딩 형태로 저장할 지 결정
   ☞ 원-핫 인코딩 : 정답을 뜻하는 원소만 1, 나머지는 0의 값을 가진다.
   [0,0,0,1,0,0,0]
   '''

   return x_train, y_train, x_test, y_test

def is_number(s):
   try:
      int(s)
      return True
   except ValueError:
      return False

def TestSN(input_i, x_train, y_train, x_test, y_test, W, Bias): #test 이미지를 하나 뽑고 singleNN.py의 trainingAndResult를 돌려서 학습전 결과와 학습 후 결과가 어떻게 다른지 확인하는 것
   if is_number(input_i):
      i = int(input_i)
      Test= x_train[i]
      label = np.argmax(y_train[i])
      img_show(Test)
      print("이 이미지의 실제 값 : ", label) #그림의 숫자와 동일
      SN = sn.singleLayer(W, Bias)
      y_predict = SN.ScoreFunction(x_train[i])
      print("이 이미지의 학습 전 이미지의 추론 값 : ", np.argmax(y_predict)) #추론값의 결과가 그림의 숫자와 같을 수도 다를 수도 있음.
      SN.Optimization(x_train, y_train, x_test, y_test)
      y_predict = SN.ScoreFunction(x_train[i])
      print("학습이 완료되었습니다 \n이미지의 학습 후 추론 값: ", np.argmax(y_predict)) #트레이닝 후의 추론값 또한 결과값과 다를 수도 있다.(정확도가 87% 정도이기에)
      return SN

   else:
      print("잘못 입력하셨습니다. 학습을 하지 않습니다.")
      return False


x_train, y_train, x_test, y_test = get_data()
# W값과 Bias 값을 np.random.random 함수를 사용해 알맞게 넣어주십시오.(이 것만 빈칸 나머지는 제공)
# 3.1
W= np.zeros([784,10])
'''
mnist Training dataset의 shape는 (60000, 784)이고, y의 클래스(레이블) 개수는 10이다.
여러개의 이미지셋 [N,784] 넘파이 배열과 가중치 W 넘파이 배열에 np.doc연산을 하여 
10개의 레이블을 가지는 [N,10] 넘파이 배열을 만들어야 한다.
따라서 가중치 W 넘파이 배열은 [784,10]의 shape을 가져야 한다. [N,784] doc [784,10] => [N,10]
'''

Bias =np.zeros([10,])
'''
( x_train * W )  넘파이 배열의 각각 행마다(이미지 마다) 일정한 Bias값들이 더해져야 하므로 
Bias는 10개의 원소를 가지는 [10,] 넘파이 배열 shape를 가져야 한다.
'''
W = np.random.random([784,10])
Bias = np.random.random([10,])

'''
W에는 [784,10] 넘파이 배열 전체에 임의의 값을 넣어줘야 하기때문에 random함수의 인자값으로 [784,10]을 넣는다.
Bias에는 [10,] 넘파이 배열 전체에 임의의 값을 넣어줘야 하기때문에 random함수의인자값으로 [10,]을 넣는다. 
'''

#i = input() # 자신이 원하는 숫자 넣기 가능
i = 5
print("train 데이터의 {} 번째의 값 추출".format(i))

Trainend = TestSN(i, x_train, y_train, x_test, y_test, W, Bias) # 위의 TestNN함수를 호출해 작업을 돌림.

#밑에 것은 심심하면 자신이 트레이닝한 것이 잘되는지 실험해보세요.
'''
if Trainend !=False:
   TrainNN =Trainend
   print("몇 번 추론하실 겁니까?")
   iterator = input()
   if(is_number(iterator)):
      for i in range(0, int(iterator)):
         print("x_train의 s번째 데이터를 뽑아주세요.\n")
         s = int(input())
         print("S : {}".format(s))
         check = x_train[s]
         img_show(check)
         Hypothesis = TrainNN.Forward(check)
         print("이 이미지의 추론 값 : {}".format(np.argmax(Hypothesis)))
   else:
      print("iterator로 숫자를 안넣었습니다. 종료합니다.")
'''



